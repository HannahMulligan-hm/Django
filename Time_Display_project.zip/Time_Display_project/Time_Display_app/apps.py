from django.apps import AppConfig


class TimeDisplayAppConfig(AppConfig):
    name = 'Time_Display_app'
