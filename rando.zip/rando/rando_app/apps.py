from django.apps import AppConfig


class RandoAppConfig(AppConfig):
    name = 'rando_app'
