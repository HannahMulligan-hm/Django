
from django.shortcuts import render, redirect
def index(request):
    return render(request,"index.html")

def result(request):
    if request.method == "GET":
        val1 = request.GET["your_name"]
        val2 = request.GET["Dojo_location"]
        val3 = request.GET["favorite_language"]
        val4 = request.GET["comment"]
        return render(request, "index.html")

# Create your views here.

