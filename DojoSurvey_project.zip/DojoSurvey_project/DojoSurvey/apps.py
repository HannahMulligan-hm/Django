from django.apps import AppConfig


class DojosurveyConfig(AppConfig):
    name = 'DojoSurvey'
