from django.db import models

class LoginManager(models.Manager):
    def basic_validator(self,postDATA):
        errors = {}

        if len(postData['first__name']) < 2:
            errors["first_name"] = "First name should be at least 2 characters"
        if len(postData['last_name']) < 2:
            errors["last_name"] = "Last name must be at least 2 characters"
        if re.match('\b[\w\.-]+@[\w\.-]+\.\w{2,4}\b', email) !=None:
            errors["email"] = "Invalid email"

class User(models.Model):
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    email = models.CharField(max_length=45)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = LoginManager()
# Create your models here.

class Book(models.Model):
    title = models.CharField(max_length=255)
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    uploaded_by = models.ForeignKey(User, related_name="books_uploaded", on_delete=models.CASCADE)
    users_who_like = models.ManyToManyField(User, related_name="liked_books")

# class LoginManager(models.Manager):
#     def basic_validator(self,postDATA):
#         errors = {}

#         if len(postData['first__name']) < 2:
#             errors["first_name"] = "First name should be at least 2 characters"
#         if len(postData['last_name']) < 2:
#             errors["last_name"] = "Last name must be at least 2 characters"
#         if re.match('\b[\w\.-]+@[\w\.-]+\.\w{2,4}\b', email) !=None:
#             errors["email"] = "Invalid email"
        