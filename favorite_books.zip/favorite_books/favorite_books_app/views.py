from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages

from .models import User
def update(request,id):
    errors = Login.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        user = User.objects.get(id = id)
        user.name = request.POST['name']
        user.desc = request.POST['desc']
        user.save()
        messages.success(request,"User successfully updated")
        return redirect('/')

def index(request):
    return render(request, "login.html")
# Create your views here.
