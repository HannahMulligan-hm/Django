from django.apps import AppConfig


class Assignment1AppConfig(AppConfig):
    name = 'assignment1_app'
